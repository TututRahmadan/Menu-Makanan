package com.example.aplikasimenu;

public class ItemModel {
    String nama;
    String harga;
    String deskripsi;
    int gambarnya;

    public ItemModel(String nama, String harga, int gambarnya, String deskripsi) {
        this.nama=nama;
        this.harga=harga;
        this.gambarnya=gambarnya;
        this.deskripsi=deskripsi;
    }



    public String getNama() {
        return nama;
    }


    public String getHarga() {
        return harga;
    }


    public int getGambarnya() {
        return gambarnya;
    }

    public String getDeskripsi() {

        return deskripsi;
    }
}
