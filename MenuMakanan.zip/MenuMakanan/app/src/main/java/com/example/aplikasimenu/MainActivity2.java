package com.example.aplikasimenu;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity {

    ArrayList<ItemModel> data2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        TextView txtDeskripsi=findViewById(R.id.deskripsi);
        ImageView gambarDetail=findViewById(R.id.gambarDetail);

        data2=new ArrayList<>();
        String deskripsi ="Deskripsi tidak tersedia";
        Bundle extras=getIntent().getExtras();
        if (extras != null){
            deskripsi = extras.getString(deskripsi);
        }

        txtDeskripsi.setText(deskripsi);
        gambarDetail.setImageResource(R.drawable.geprek);
        gambarDetail.setImageResource(R.drawable.soto);
        gambarDetail.setImageResource(R.drawable.kari_ayam);
        gambarDetail.setImageResource(R.drawable.nasi_goreng);
        gambarDetail.setImageResource(R.drawable.pecel_lele);
        gambarDetail.setImageResource(R.drawable.tahu_bulat);



    }
}