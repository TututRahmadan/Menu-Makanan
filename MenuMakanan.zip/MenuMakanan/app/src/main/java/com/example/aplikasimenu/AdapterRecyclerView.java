package com.example.aplikasimenu;


import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

    public class  AdapterRecyclerView extends RecyclerView.Adapter<AdapterRecyclerView.ViewHolder> {

        private  ArrayList<ItemModel> dataItem;
        private static   RecyclerViewOnClick listener;

        AdapterRecyclerView(ArrayList<ItemModel> dataItem, RecyclerViewOnClick listener) {
            this.dataItem = dataItem;
            this.listener = listener;
        }


        @Override
        public AdapterRecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item, parent, false);
            return new ViewHolder(view);
        }


        public static class ViewHolder extends RecyclerView.ViewHolder implements com.example.aplikasimenu.ViewHolder {
            TextView txtNamaMakanan;
            TextView txtHargaMakanan;
            ImageView GambarMakanan;


            public ViewHolder(View itemView) {
                super(itemView);
                txtNamaMakanan = itemView.findViewById(R.id.nama_makanan);
                txtHargaMakanan = itemView.findViewById(R.id.harga_makanan);
                GambarMakanan = itemView.findViewById(R.id.gambar_list);
                itemView.setOnClickListener((View.OnClickListener) this);

            }

            @Override
            public void onClick(View v) {
                listener.onClick(itemView, getAdapterPosition());
            }
        }


        @Override
        public void onBindViewHolder(AdapterRecyclerView.ViewHolder holder, int position) {
            /*TextView txtNamaMakanan= holder.txtNamaMakanan;
            TextView txtHargaMakanan=holder.txtHargaMakanan;
            ImageView GambarMakanan=holder.GambarMakanan;
            */
            holder.txtNamaMakanan.setText(dataItem.get(position).getNama());
            holder.txtHargaMakanan.setText(dataItem.get(position).getHarga());
            holder.GambarMakanan.setImageResource(dataItem.get(position).getGambarnya());

        }

        @Override
        public int getItemCount() {
            return dataItem != null ? dataItem.size() : 0;
        }


        public interface RecyclerViewOnClick {
            void onClick(View view, int position);
        }
    }

