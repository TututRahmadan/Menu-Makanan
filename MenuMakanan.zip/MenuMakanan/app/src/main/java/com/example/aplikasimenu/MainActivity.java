package com.example.aplikasimenu;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import java.util.ArrayList;


@SuppressWarnings("rawtypes")
public class MainActivity extends AppCompatActivity {

    ArrayList<ItemModel> data;
    RecyclerView.LayoutManager recyclerViewLayoutManager = new LinearLayoutManager(this);
    RecyclerView recyclerView;
    AdapterRecyclerView.RecyclerViewOnClick listener;
    //RecyclerView.Adapter adapterRecyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);

        recyclerView.setLayoutManager(recyclerViewLayoutManager);
        recyclerView.setHasFixedSize(true);
        recyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        AdapterRecyclerView adapter = new AdapterRecyclerView(data, listener);
        recyclerView.setAdapter(adapter);

        addData();
        setOnClickListener();

    }

    void addData() {
        data = new ArrayList<>();
        data.add(new ItemModel("Pecel Lele", "Rp.15.000", R.drawable.pecel_lele,"Lele goreng sambal dan lalapan"));
        data.add(new ItemModel("Kari Ayam", "Rp.20.000", R.drawable.kari_ayam,"Ayam bumbu kari"));
        data.add(new ItemModel("Ayam Geprek", "Rp.10.000", R.drawable.geprek,"Ayam di geprek"));
        data.add(new ItemModel("Nasi Goreng", "Rp.15.000", R.drawable.nasi_goreng,"Nasi di goreng"));
        data.add(new ItemModel("Soto", "Rp.12.000", R.drawable.soto,"Kari tanpa santan"));
        data.add(new ItemModel("Tahu Bulat", "Rp.500", R.drawable.tahu_bulat, "Tahunya bulat"));
    }

    private void setOnClickListener() {
        listener = (view, position) -> {
            Intent intent = new Intent(getApplicationContext(), MainActivity2.class);
            intent.putExtra("deskripsi", data.get(position).getDeskripsi());
            startActivity(intent);
        };
    }
}