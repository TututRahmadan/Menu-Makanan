package com.example.aplikasimenu;

import android.view.View;

public interface ViewHolder {
    void onClick(View v);
}
