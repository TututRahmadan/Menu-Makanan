package com.example.aplikasimenu;

public class Item {

    public static int[] gambarMakanan = new int[]{
            R.drawable.pecel_lele, R.drawable.kari_ayam,
            R.drawable.geprek, R.drawable.nasi_goreng,
            R.drawable.soto, R.drawable.tahu_bulat
    };

    public static String[] namaMakanan={
            "Pecel Lele","Kari Ayam","Ayam Geprek","Nasi Goreng","Soto","Tahu Bulat"};

    public static String[] hargaMakanan={
            "Rp 15.000","Rp 20.000","Rp 25.000","Rp 17.000","Rp 15.000","Rp 1000"
    };
    /**/

    /*public static ArrayList<ItemModel> setDataItem() {
        ArrayList<ItemModel> dataItem = new ArrayList<>();
        for (int position = 0; position < namaMakanan.length; position++) {
            ItemModel itemModel = new ItemModel(namaMakanan[position],hargaMakanan[position],gambarMakanan[position],deskripsiMakanan[position]);
            dataItem.add(itemModel);
        }return dataItem;

    }*/

}

